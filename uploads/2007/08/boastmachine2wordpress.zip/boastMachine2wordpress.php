<?php 
require "setup_options.php";
require "setup_mysql.php";

post2cat();
categories();
posts();
comments();

//updateCommentsCount();

function updateCommentsCount(){
$result=mysql_query("select * from wp_posts");
			while($rs=mysql_fetch_array($result)){
			
			$result2=mysql_query("select count(*) from wp_comments where comment_post_ID={$rs['ID']}");
			$rs2=mysql_fetch_array($result2);
			
			if($rs2[0]>0){
			echo $rs['ID'].'->'.$rs2[0].'<br>';
			mysql_query("update wp_posts set comment_count={$rs2[0]} where ID={$rs['ID']}");}
			}

}

function comments(){
echo "-- 
-- 表的结构 `wp_comments`
-- 

DROP TABLE IF EXISTS `wp_comments`;
CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL auto_increment,
  `comment_post_ID` int(11) NOT NULL default '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL default '',
  `comment_author_url` varchar(200) NOT NULL default '',
  `comment_author_IP` varchar(100) NOT NULL default '',
  `comment_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL default '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL default '0',
  `comment_approved` enum('0','1','spam') NOT NULL default '1',
  `comment_agent` varchar(255) NOT NULL default '',
  `comment_type` varchar(20) NOT NULL default '',
  `comment_parent` bigint(20) NOT NULL default '0',
  `user_id` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`comment_ID`),
  KEY `comment_approved` (`comment_approved`),
  KEY `comment_post_ID` (`comment_post_ID`)
) TYPE=MyISAM AUTO_INCREMENT=0 ;

-- 
-- 导出表中的数据 `wp_comments`
-- 


";

$result=mysql_query("select * from bmc_comments");
			while($rs=mysql_fetch_array($result)){
			$dt=date('Y-m-d H:i:s',$rs['date']);
			if(true)echo "INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES (null, {$rs['post']}, '{$rs['auth_name']}', '{$rs['auth_email']}', '{$rs['auth_url']}', '{$rs['auth_ip'] }', '{$dt}', '{$dt}', '{$rs['data']}', 0, '1', '', '', 0, 0);
";
			}

}



function posts(){

echo "-- 
-- 表的结构 `wp_posts`
-- 

DROP TABLE IF EXISTS `wp_posts`;
CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL auto_increment,
  `post_author` bigint(20) NOT NULL default '0',
  `post_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL default '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_category` int(4) NOT NULL default '0',
  `post_excerpt` text NOT NULL,
  `post_status` enum('publish','draft','private','static','object','attachment','inherit','future') NOT NULL default 'publish',
  `comment_status` enum('open','closed','registered_only') NOT NULL default 'open',
  `ping_status` enum('open','closed') NOT NULL default 'open',
  `post_password` varchar(20) NOT NULL default '',
  `post_name` varchar(200) NOT NULL default '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL default '0000-00-00 00:00:00',
  `post_content_filtered` text NOT NULL,
  `post_parent` bigint(20) NOT NULL default '0',
  `guid` varchar(255) NOT NULL default '',
  `menu_order` int(11) NOT NULL default '0',
  `post_type` varchar(20) NOT NULL default 'post',
  `post_mime_type` varchar(100) NOT NULL default '',
  `comment_count` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`)
) TYPE=MyISAM AUTO_INCREMENT=0 ;

-- 
-- 导出表中的数据 `wp_posts`
-- 

";


$result=mysql_query("select * from bmc_posts order by id");
			while($rs=mysql_fetch_array($result)){
$dt=$rs['time'];
$content=$rs['summary'];
if (strlen($rs['summary'])<$rs['data'])$content=$rs['data'];

$content=str_replace('[img]','<img src="',$content);
$content=str_replace('[/img]','" />',$content);
//[/img][/url]
//[url=http://www.cbmland.com/files/cbm_IMG2733.jpg]
$content=str_replace('[url=','<a href="',$content);
$content=str_replace('[/url]','</a>',$content);

$content=str_replace(']<img','"><img',$content);

$post_name=(str_replace(' ','.',str_replace("'","\'",$rs['title'])));
$post_name=strtolower($post_name);
$dt=date('Y-m-d H:i:s',$rs['date']);

if(true){echo "INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_category`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES ({$rs['id']}, 1, '{$dt}', '{$dt}', '{$content}', '{$rs['title']}', 0, '', 'publish', 'open', 'open', '', '{$post_name}', '', '', '{$dt}', '{$dt}', '', 0, 'http://www.cbmland.com/post/{$rs['id']}/{$post_name}.html', 0, 'post', '', 0);
";
}else{
$content="content";

//$title=(str_replace("'","\'",$rs['title']));
//$post_name2=(str_replace(' ','.',$title));

echo "INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_category`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES ({$rs['id']}, 1, '{$dt}', '{$dt}', '{$content}', '{$title}', 0, '', 'publish', 'open', 'open', '', '{$post_name}', '', '', '{$dt}', '{$dt}', '', 0, 'http://www.cbmland.com/post/{$rs['id']}/{$post_name}.html', 0, 'post', '', 0);
";
}

}


}



function categories(){

echo "-- 
-- 表的结构 `wp_categories`
-- 

DROP TABLE IF EXISTS `wp_categories`;
CREATE TABLE `wp_categories` (
  `cat_ID` bigint(20) NOT NULL auto_increment,
  `cat_name` varchar(55) NOT NULL default '',
  `category_nicename` varchar(200) NOT NULL default '',
  `category_description` longtext NOT NULL,
  `category_parent` bigint(20) NOT NULL default '0',
  `category_count` bigint(20) NOT NULL default '0',
  `link_count` bigint(20) NOT NULL default '0',
  `posts_private` tinyint(1) NOT NULL default '0',
  `links_private` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`cat_ID`),
  KEY `category_nicename` (`category_nicename`)
) TYPE=MyISAM AUTO_INCREMENT=0 ;

-- 
-- 导出表中的数据 `wp_categories`
-- 

INSERT INTO `wp_categories` (`cat_ID`, `cat_name`, `category_nicename`, `category_description`, `category_parent`, `category_count`, `link_count`, `posts_private`, `links_private`) VALUES (1, '未分类', '%e6%9c%aa%e5%88%86%e7%b1%bb', '', 0, 11, 0, 0, 0);
INSERT INTO `wp_categories` (`cat_ID`, `cat_name`, `category_nicename`, `category_description`, `category_parent`, `category_count`, `link_count`, `posts_private`, `links_private`) VALUES (2, '链接', '%e9%93%be%e6%8e%a5', '', 0, 0, 7, 0, 0);

";



	$result=mysql_query("select * from bmc_cats");
			while($rs=mysql_fetch_array($result)){
			
							echo "INSERT INTO `wp_categories` (`cat_ID`, `cat_name`, `category_nicename`, `category_description`, `category_parent`, `category_count`, `link_count`, `posts_private`, `links_private`) VALUES ({$rs['id']}, '{$rs['cat_name']}', '".rawurlencode(str_replace(' ','-',$rs['cat_name']))."', '{$rs['cat_info']}', 0, {$rs['cats_count']}, 0, 0, 0);\n";
	
	}


}


function post2cat(){

echo "DROP TABLE IF EXISTS `wp_post2cat`;
CREATE TABLE `wp_post2cat` (
  `rel_id` bigint(20) NOT NULL auto_increment,
  `post_id` bigint(20) NOT NULL default '0',
  `category_id` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`rel_id`),
  KEY `post_id` (`post_id`,`category_id`)
) TYPE=MyISAM AUTO_INCREMENT=0 ;

";

	$result=mysql_query("select * from bmc_post2cat");
			while($rs=mysql_fetch_array($result)){
							echo "INSERT INTO `wp_post2cat` (`rel_id`, `post_id`, `category_id`) VALUES (null, {$rs['post_id']}, {$rs['cat_id']});\n";
	
	}


}
?>