<?php
/*
Plugin Name: Arctic's Internal Alexa Redirect(Optimized by CBM)
Plugin URI: http://hellobmw.com/archives/arctics-internal-alexa-redirect-a-wordpress-plugin-to-improve-your-alexa-ranking.html
Description: Adds an Alexa Redirect Link to all of your internal links' onclick property to <strong>improve Alexa Ranking but keep URLs SEO friendly.</strong>
Author: cbm
Version: 1.2-cbm
Author URI: http://cbmland.com/
*/

/* Change log
Version 1.2-cbm (Aug 16th, 2007)
	NEW: Add Redirect Referer,Optimized onClick Event. Optimized By cbm
Version 1.1 (Aug 12th, 2007)
	NEW: Added Function to exclude some URLs
Version 1.0 (Aug 3rd, 2007)
	NEW: Initial Release
*/

/*
Original idea: Ariah Fine
Based on: Internal Alexa Redirect http://blog.iamnotashamed.net/projects/wordpress-plugins/

I decided to modify this plugin as it made links SEO UNFRIENDLY.
And the modified plugin will add the Alexa Redirect Link to URLs as an "onclick" property instead.

Copyright 2007	Ariah Fine (email: ariahfine@gmail.com)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

*/

### Function: Displays Redirect Function
add_action('wp_head', 'the_redirect_func');
function the_redirect_func() {
echo '<script language="javascript">function e(e){
var hrefs=e.href.split("?");
var href=hrefs[hrefs.length-1];
e.href="http://redirect.alexa.com/redirect?"+href;
}
</script>';
}


// Apply to entire blog but not to WP admin

	if ( strpos($_SERVER['REQUEST_URI'], 'wp-admin') === false ) {

		add_action('template_redirect','ttf_do_ob_start');
	}

function ttf_do_ob_start() {
	ob_start('wp_lzw_external_links');
}

function wp_lzw_get_domain_name_from_uri($uri) {
	preg_match("/^(http:\/\/)?([^\/]+)/i", $uri, $matches);
	$host = $matches[2];
	preg_match("/[^\.\/]+\.[^\.\/]+$/", $host, $matches);
	return $matches[0];	   
}


function wp_lzw_parse_external_links($matches) {
	if ( wp_lzw_get_domain_name_from_uri($matches[3]) == wp_lzw_get_domain_name_from_uri($_SERVER["HTTP_HOST"]) && wp_lzw_exclude($matches[3]) == true ) {
		return '<a href="' . $matches[2] . '//' . $matches[3] . '"' . $matches[1] . $matches[4] . ' onclick="e(this)">' . $matches[5] . '</a>';
	}
	else {
		return '<a href="' . $matches[2] . '//' . $matches[3] . '"' . $matches[1] . $matches[4] . '>' . $matches[5] . '</a>';
	}
}


function wp_lzw_external_links($text) {

	$pattern = '/<a (.*?)href="(.*?)\/\/(.*?)"(.*?)>(.*?)<\/a>/';
	$text = preg_replace_callback($pattern,'wp_lzw_parse_external_links',$text);

	return $text;
}

function wp_lzw_exclude($source) {
	
	/*
	If you prefer keeping URLs that include a specific string away from Alexa Redirect Link,
	just add this string to the $words array as the following format:
	$words = array ('string1', 'string2', 'string3');
	*/
	$words = array ('/wp-admin/');
	foreach ( $words as $word ) {
  	if ( strstr($source, $word) ) {
  		return false;
  	} else {
  		$flag = true;
  	}
  }
  return $flag;

}
